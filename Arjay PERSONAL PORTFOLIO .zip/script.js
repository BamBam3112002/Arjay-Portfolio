document.addEventListener("DOMContentLoaded", () => {

    // ======== 1. Mobile Hamburger Menu (Improved UX) ========
    const hamburger = document.querySelector(".hamburger");
    const navMenu = document.querySelector(".nav-menu");
    const navCloseBtn = document.querySelector(".nav-close-btn");
    const body = document.body;

    function closeMenu() {
        navMenu.classList.remove("active");
        // Re-enables scrolling on the background page
        body.classList.remove("no-scroll"); 
    }

    if (hamburger) {
        hamburger.addEventListener("click", () => {
            navMenu.classList.add("active");
            // Prevents the background page from scrolling when the menu is open
            body.classList.add("no-scroll");
        });
    }

    if (navCloseBtn) {
        navCloseBtn.addEventListener("click", closeMenu);
    }

    // ======== 2. Typing Text Animation ========
    const typingText = document.querySelector(".typing-text");
    const textArray = [
        "Computer Engineering Student",
        "Video Editor",
        "Call Center Agent / IT",
        "DJ Prod"
    ];
    let textIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    const typeSpeed = 120;
    const deleteSpeed = 80;
    const delay = 2000;

    function type() {
        if (!typingText) return; 
        const currentText = textArray[textIndex];
        
        if (isDeleting) {
            charIndex--;
            typingText.textContent = currentText.substring(0, charIndex);
            if (charIndex === 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % textArray.length;
                setTimeout(type, 500);
            } else {
                setTimeout(type, deleteSpeed);
            }
        } else {
            charIndex++;
            typingText.textContent = currentText.substring(0, charIndex);
            if (charIndex === currentText.length) {
                isDeleting = true;
                setTimeout(type, delay);
            } else {
                setTimeout(type, typeSpeed);
            }
        }
    }
    type();

    // ======== 3. Smooth Scroll and Menu Close (ADVANCED UX) ========
    // Handles smooth scrolling to sections and closes the menu if open
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            if (this.hash) {
                e.preventDefault();
                
                // Close the mobile menu first
                if (navMenu.classList.contains("active")) {
                     closeMenu(); 
                }

                // Smoothly scroll to the target section
                document.querySelector(this.hash).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // ======== 4. Fade-in Section on Scroll ========
    const sectionsToFade = document.querySelectorAll(".fade-in");
    const options = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("visible");
                observer.unobserve(entry.target);
            }
        });
    }, options);
    sectionsToFade.forEach(section => {
        observer.observe(section);
    });

    // ======== 5. Sticky/Shrinking Header on Scroll (ADVANCED UX) ========
    const header = document.querySelector(".header");
    const scrollThreshold = 100;

    function handleScroll() {
        if (header) { 
            // Adds 'scrolled' class for CSS to shrink/change the header
            if (window.scrollY > scrollThreshold) {
                header.classList.add("scrolled");
            } else {
                header.classList.remove("scrolled");
            }
        }
    }
    window.addEventListener("scroll", handleScroll);

  // ======== 6. Basic Client-Side Form Validation (ADVANCED UX) ========
const contactForm = document.getElementById("contact-form");

// 🚨 IMPORTANT: Replace this URL with the actual endpoint provided by your form service 
// (e.g., Formspree, Netlify Forms, etc.).
const FORM_SUBMISSION_URL = "https://formspree.io/f/xldavpyl"; 

if (contactForm) {
    contactForm.addEventListener("submit", function(e) {
        // Prevent default form submission to handle it with JavaScript
        e.preventDefault(); 

        const nameInput = contactForm.querySelector('input[name="name"]');
        const emailInput = contactForm.querySelector('input[type="email"]');
        const messageArea = contactForm.querySelector('textarea[name="message"]');
        
        // --- 1. Validation Checks ---
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; 

        if (!emailRegex.test(emailInput.value)) {
            alert("Please enter a valid email address.");
            emailInput.focus();
            return;
        }

        if (messageArea.value.length < 10) {
            alert("Your message should be at least 10 characters long.");
            messageArea.focus();
            return;
        }

        // --- 2. Collect Data ---
        // Create an object to hold the form data
        const formData = {
            name: nameInput.value,
            email: emailInput.value,
            message: messageArea.value
        };

        // --- 3. Submission using Fetch API ---
        // Fetch is a modern way to send data asynchronously (AJAX)
        fetch(FORM_SUBMISSION_URL, {
            method: 'POST', // Use POST method to send data
            headers: {
                'Content-Type': 'application/json' // Tell the server the data is JSON
            },
            body: JSON.stringify(formData) // Convert the JavaScript object to a JSON string
        })
        .then(response => {
            // Check if the server responded with a successful status code (200-299)
            if (response.ok) {
                alert(`Thank you for your message, ${formData.name}! It has been successfully sent.`);
                contactForm.reset(); // Clear the form fields
            } else {
                // If the server returns an error code (e.g., 404, 500)
                alert("Oops! There was an error submitting your message. Please try again later or email me directly.");
            }
        })
        .catch(error => {
            // Catches network errors (e.g., server offline, connection lost)
            console.error('Submission Error:', error);
            alert("A network error occurred. Please check your connection.");
        });
    });
}


    // ======== 7. Dynamic Copyright Year ========
    const yearSpan = document.getElementById("current-year");
    if(yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});
